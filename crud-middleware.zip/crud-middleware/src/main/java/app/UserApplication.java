package app;

import annotation.MiddlewareApplication;

@MiddlewareApplication
public class UserApplication {
    public static void main(String[] args) {
        broker.MiddlewareApplication.run(UserApplication.class, args);
    }
}
