package app;

public class User {
    private int id;
    private String name;
    private Integer age;

    public User() {}

    public User(String name, Integer age) {
        this.name = name;
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String toString() {
        return "{\n"
                +"\t\"id\":\"" + id + "\",\n"
                +"\t\"name\":\"" + name + "\",\n"
                +"\t\"age\":" + age + "\n}";
    }
}
