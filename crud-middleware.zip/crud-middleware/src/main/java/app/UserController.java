package app;

import annotation.Component;
import annotation.parameters.PathVariable;
import annotation.parameters.RequestBody;
import annotation.web.*;

import java.util.List;

@RequestMapping("/users")
@Component
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @Get
    public List<User> findAll() {
        return userService.getUsers();
    }

    @Get("/{id}")
    public User findById(@PathVariable("id") int id) {
        return userService.getUser(id);
    }

    @Post
    public boolean save(@RequestBody User user) {
        return userService.addUser(user);
    }

    @Put("/{id}")
    public void update(@RequestBody User user, @PathVariable("id") int id) {
        userService.updateUser(id, user);
    }

    @Delete("/{id}")
    public void delete(@PathVariable("id") int id) {
        userService.deleteUser(id);
    }
}
