package app;

import annotation.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class UserService {
    private final List<User> users;

    public UserService() {
        this.users = new ArrayList<>();
    }

    public boolean addUser(User user) {
        int id = users.size();
        user.setId(id);
        return users.add(user);
    }

    public List<User> getUsers() {
        return List.copyOf(users);
    }

    public User getUser(int id) {
        User user = null;
        user = users.get(id);
        return user;
    }

    public void deleteUser(int id) {
        users.remove(id);
    }

    public void updateUser(int id, User user) {
        users.get(id).setName(user.getName());
        users.get(id).setAge(user.getAge());
    }
}
